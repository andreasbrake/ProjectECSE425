# ECSE 425 Project Assembler Code
(repository at https://github.com/andreasbrake/ProjectECSE425)

To build, run `make` or manually with gcc

To run the assembler use the syntax

    assembler <input_file>

This will result in the file output.bin containing the MIPS machine code

####Group Memebers: 
* Andreas Brake
* Martin Dorel
* Justin Gelinas-Delisle
* Mete Kemertas
* Eric Liou
