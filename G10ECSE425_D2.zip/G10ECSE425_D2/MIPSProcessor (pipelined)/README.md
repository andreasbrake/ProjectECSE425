# ECSE 425 Project Assembler Code

####Group Memebers: 
* Andreas Brake
* Martin Dorel
* Justin Gelinas-Delisle
* Mete Kemertas
* Eric Liou


#### Running
The reset is intended to be run for *one* clock cycle before regular actions begin in order to set initial values.

We have tested on a clock cycle of 50ns